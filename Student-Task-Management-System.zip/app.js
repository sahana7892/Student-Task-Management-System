const STORAGE_KEY = "studywell-student-tasks-v1";

const starterTasks = [
  {
    id: "starter-complete-task",
    title: "Complete Task",
    subtasks: [
      { id: "add-complete-option", title: "Add complete option", done: false },
      { id: "change-task-status", title: "Change task status", done: false },
      { id: "save-completion-status", title: "Save completion status", done: false },
      { id: "display-completed-status", title: "Display completed status", done: false },
      { id: "task-completion", title: "Task completion", done: false }
    ]
  }
];

let tasks = loadTasks();
let activeFilter = "all";

const taskList = document.querySelector("#task-list");
const taskForm = document.querySelector("#task-form");
const taskTitleInput = document.querySelector("#task-title");

function loadTasks() {
  try {
    const storedTasks = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(storedTasks) && storedTasks.every(isValidTask)) return storedTasks;
  } catch {
    // Start fresh if saved data is unavailable or malformed.
  }
  return structuredClone(starterTasks);
}

function isValidTask(task) {
  return task && typeof task.id === "string" && typeof task.title === "string" &&
    Array.isArray(task.subtasks) && task.subtasks.every((subtask) =>
      subtask && typeof subtask.id === "string" && typeof subtask.title === "string" && typeof subtask.done === "boolean");
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function taskStatus(task) {
  if (task.subtasks.length === 0) return task.completed ? "Completed" : "Not started";
  if (task.subtasks.length > 0 && task.subtasks.every((subtask) => subtask.done)) return "Completed";
  if (task.subtasks.some((subtask) => subtask.done)) return "In progress";
  return "Not started";
}

function makeElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function makeTaskCard(task) {
  const status = taskStatus(task);
  const completedCount = task.subtasks.filter((subtask) => subtask.done).length;
  const card = makeElement("article", `task-card${status === "Completed" ? " is-completed" : ""}`);
  const header = makeElement("div", "task-card-header");
  const completeCheckbox = makeElement("input", "task-main-check");
  completeCheckbox.type = "checkbox";
  completeCheckbox.checked = status === "Completed";
  completeCheckbox.setAttribute("aria-label", `Mark ${task.title} ${completeCheckbox.checked ? "not completed" : "completed"}`);
  completeCheckbox.addEventListener("change", () => setTaskCompletion(task.id, completeCheckbox.checked));

  const titleWrap = makeElement("div", "task-title-wrap");
  titleWrap.append(makeElement("h3", "task-title", task.title));

  const statusBadge = makeElement("span", `task-status status-${status.toLowerCase().replaceAll(" ", "-")}`, status);
  statusBadge.setAttribute("aria-label", `Status: ${status}`);

  const completeButton = makeElement("button", "complete-button", status === "Completed" ? "Undo" : "Complete");
  completeButton.type = "button";
  completeButton.setAttribute("aria-label", `${status === "Completed" ? "Reopen" : "Complete"} task: ${task.title}`);
  completeButton.addEventListener("click", () => setTaskCompletion(task.id, status !== "Completed"));

  const deleteButton = makeElement("button", "delete-button", "Delete");
  deleteButton.type = "button";
  deleteButton.setAttribute("aria-label", `Delete task: ${task.title}`);
  deleteButton.addEventListener("click", () => deleteTask(task.id));
  header.append(completeCheckbox, titleWrap, statusBadge, completeButton, deleteButton);

  const progress = makeElement("div", "task-progress");
  const track = makeElement("div", "progress-track");
  track.setAttribute("role", "progressbar");
  track.setAttribute("aria-label", `Progress for ${task.title}`);
  track.setAttribute("aria-valuemin", "0");
  track.setAttribute("aria-valuemax", String(task.subtasks.length));
  track.setAttribute("aria-valuenow", String(completedCount));
  const fill = makeElement("div", "progress-fill");
  fill.style.width = `${task.subtasks.length ? completedCount / task.subtasks.length * 100 : 0}%`;
  track.append(fill);
  progress.append(track, makeElement("span", "progress-label", `${completedCount} of ${task.subtasks.length} done`));

  const subtaskList = makeElement("ul", "subtask-list");
  task.subtasks.forEach((subtask) => subtaskList.append(makeSubtaskRow(task.id, subtask)));

  const addSubtaskForm = makeElement("form", "add-subtask-form");
  const subtaskInput = makeElement("input");
  subtaskInput.type = "text";
  subtaskInput.name = "subtask";
  subtaskInput.maxLength = 100;
  subtaskInput.placeholder = "Add a step...";
  subtaskInput.setAttribute("aria-label", `Add a step to ${task.title}`);
  subtaskInput.required = true;
  const addSubtaskButton = makeElement("button", "", "+ Add step");
  addSubtaskButton.type = "submit";
  addSubtaskForm.append(subtaskInput, addSubtaskButton);
  addSubtaskForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const title = subtaskInput.value.trim();
    if (!title) return;
    addSubtask(task.id, title);
  });

  card.append(header, progress, subtaskList, addSubtaskForm);
  return card;
}

function makeSubtaskRow(taskId, subtask) {
  const row = makeElement("li", `subtask-row${subtask.done ? " is-done" : ""}`);
  const checkbox = makeElement("input", "subtask-check");
  checkbox.type = "checkbox";
  checkbox.checked = subtask.done;
  checkbox.setAttribute("aria-label", `${subtask.done ? "Mark incomplete" : "Complete"}: ${subtask.title}`);
  checkbox.addEventListener("change", () => toggleSubtask(taskId, subtask.id));

  const label = makeElement("span", "subtask-label", subtask.title);
  const removeButton = makeElement("button", "remove-subtask", "×");
  removeButton.type = "button";
  removeButton.setAttribute("aria-label", `Remove step: ${subtask.title}`);
  removeButton.addEventListener("click", () => removeSubtask(taskId, subtask.id));
  row.append(checkbox, label, removeButton);
  return row;
}

function render() {
  const visibleTasks = tasks.filter((task) => {
    if (activeFilter === "active") return taskStatus(task) !== "Completed";
    if (activeFilter === "completed") return taskStatus(task) === "Completed";
    return true;
  });

  taskList.replaceChildren();
  if (visibleTasks.length) {
    visibleTasks.forEach((task) => taskList.append(makeTaskCard(task)));
  } else {
    const emptyState = makeElement("div", "empty-state");
    emptyState.append(
      makeElement("strong", "", activeFilter === "completed" ? "No completed tasks yet" : activeFilter === "active" ? "All caught up" : "Nothing on your list yet"),
      makeElement("span", "", activeFilter === "completed" ? "Finish a task and it will show up here." : "Add a task above to get started.")
    );
    taskList.append(emptyState);
  }

  const completedTasks = tasks.filter((task) => taskStatus(task) === "Completed").length;
  document.querySelector("#all-count").textContent = String(tasks.length);
  document.querySelector("#active-count").textContent = String(tasks.length - completedTasks);
  document.querySelector("#completed-count").textContent = String(completedTasks);
  document.querySelector("#summary-number").textContent = String(completedTasks);
  document.querySelector("#list-total").textContent = `${visibleTasks.length} ${visibleTasks.length === 1 ? "task" : "tasks"}`;
  document.querySelector("#list-caption").textContent = activeFilter === "completed" ? "Look at everything you have finished." : activeFilter === "active" ? "The next steps are right here." : "A clear view of what is on your plate.";
}

function updateTask(taskId, update) {
  tasks = tasks.map((task) => task.id === taskId ? update(task) : task);
  saveTasks();
  render();
}

function setTaskCompletion(taskId, completed) {
  updateTask(taskId, (task) => ({
    ...task,
    completed,
    subtasks: task.subtasks.map((subtask) => ({ ...subtask, done: completed }))
  }));
}

function toggleSubtask(taskId, subtaskId) {
  updateTask(taskId, (task) => ({
    ...task,
    subtasks: task.subtasks.map((subtask) => subtask.id === subtaskId ? { ...subtask, done: !subtask.done } : subtask)
  }));
}

function addSubtask(taskId, title) {
  updateTask(taskId, (task) => ({
    ...task,
    subtasks: [...task.subtasks, { id: crypto.randomUUID(), title, done: false }]
  }));
}

function removeSubtask(taskId, subtaskId) {
  updateTask(taskId, (task) => ({
    ...task,
    subtasks: task.subtasks.filter((subtask) => subtask.id !== subtaskId)
  }));
}

function deleteTask(taskId) {
  tasks = tasks.filter((task) => task.id !== taskId);
  saveTasks();
  render();
}

taskForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const title = taskTitleInput.value.trim();
  if (!title) return;
  tasks.unshift({ id: crypto.randomUUID(), title, subtasks: [] });
  saveTasks();
  activeFilter = "all";
  updateSelectedFilter();
  taskTitleInput.value = "";
  render();
  taskTitleInput.focus();
});

function updateSelectedFilter() {
  document.querySelectorAll("[data-filter]").forEach((button) => {
    const selected = button.dataset.filter === activeFilter;
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
}

document.querySelectorAll("[data-filter]").forEach((button) => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    updateSelectedFilter();
    render();
  });
});

document.querySelector("#today-label").textContent = new Intl.DateTimeFormat(undefined, {
  weekday: "long", month: "short", day: "numeric"
}).format(new Date());

render();