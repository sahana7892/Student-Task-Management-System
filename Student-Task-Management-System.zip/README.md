# Student Task Management System

A small browser-based task manager for tracking tasks and their completion steps. It uses plain HTML, CSS, and JavaScript, so there is nothing to install.

## Run it

Open `index.html` in a modern web browser. Task data is saved in that browser on the current device using `localStorage`.

## Features

- Create and delete tasks.
- Add, complete, and remove task steps.
- Mark a task complete or reopen it; the task status follows its steps.
- See completion progress and filter all, in-progress, or completed tasks.
- Keep task status after reloading the page.

The starter task is **Complete Task**, with these steps: Add complete option, Change task status, Save completion status, Display completed status, and Task completion.